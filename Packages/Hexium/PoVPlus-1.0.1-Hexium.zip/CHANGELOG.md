# 1.0.1

- Added the shareable gameplay configuration from the PoV Plus development profile.
