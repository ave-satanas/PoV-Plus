# PoV Plus

A Valheim modpack built around Path of Valheiman, with expanded combat, crafting, building, exploration, and quality-of-life mods.

## Installation

Install with Gale using both Hexium and Thunderstore as mod sources. This package declares 87 dependencies using the versions in the original PoV Plus list as minimums. Hexium supplies BepInEx automatically. Gale can resolve newer versions.

### Thunderstore dependencies

The following packages have Thunderstore listings. If Gale leaves any unresolved, install them from their linked package pages.

- [MidnightMods-ValheimArmory-1.38.0](https://thunderstore.io/c/valheim/p/MidnightMods/ValheimArmory/)
- [Therzie-Monstrum-1.6.1](https://thunderstore.io/c/valheim/p/Therzie/Monstrum/)
- [Therzie-Wizardry-1.2.3](https://thunderstore.io/c/valheim/p/Therzie/Wizardry/)
- [Therzie-Armory-1.4.3](https://thunderstore.io/c/valheim/p/Therzie/Armory/)
- [Therzie-Warfare-1.9.6](https://thunderstore.io/c/valheim/p/Therzie/Warfare/)
- [southsil-SouthsilArmor-3.2.2](https://thunderstore.io/c/valheim/p/southsil/SouthsilArmor/)
- [Advize-Armoire-1.2.3](https://thunderstore.io/c/valheim/p/Advize/Armoire/)
- [Gurebu-Riverheim-1.2.1](https://thunderstore.io/c/valheim/p/Gurebu/Riverheim/)
- [TastyChickenLegs-NoSmokeStayLit-2.4.4](https://thunderstore.io/c/valheim/p/TastyChickenLegs/NoSmokeStayLit/)
- [BentoG-MissingPieces-2.3.2](https://thunderstore.io/c/valheim/p/BentoG/MissingPieces/)
- [VentureValheim-Venture_Logout_Tweaks-1.0.0](https://thunderstore.io/c/valheim/p/VentureValheim/Venture_Logout_Tweaks/)
- [VentureValheim-Venture_Floating_Items-1.0.1](https://thunderstore.io/c/valheim/p/VentureValheim/Venture_Floating_Items/)
- [Crystal-Comfortable-1.2.3](https://thunderstore.io/c/valheim/p/Crystal/Comfortable/)
- [RandyKnapp-EpicLoot-0.15.6](https://thunderstore.io/c/valheim/p/RandyKnapp/EpicLoot/)
- [VentureValheim-Muted_Mist-1.0.1](https://thunderstore.io/c/valheim/p/VentureValheim/Muted_Mist/)
- [Pfhoenix-ODINFLIGHT-2.1.1](https://thunderstore.io/c/valheim/p/Pfhoenix/ODINFLIGHT/)

### Pack-specific add-ons

The original list also includes **PlanBuild PoVPlus 0.20.2** and **HearthBelow PoV Bridge 1.2.0**. Obtain those two packages separately from the pack maintainer to reproduce the original add-on set. They provide vanilla-hammer blueprint tools and Path of Valheiman scaling for HearthBelow digging, respectively.

This release includes 151 gameplay and mod configuration files from the PoV Plus development profile under `BepInEx/config/`. Use a fresh profile to apply the included settings. Dedicated server operators can copy the included config tree into the server installation as needed.

Local player and server state, credentials, backups, generated references, custom media, and configs for selected development-only mods are excluded. Custom music referenced by the world configuration may require separate files. An end-to-end installation and multiplayer playtest are pending.

## Credits

Thanks to treextr for Path of Valheiman and to the authors of the linked dependencies.
